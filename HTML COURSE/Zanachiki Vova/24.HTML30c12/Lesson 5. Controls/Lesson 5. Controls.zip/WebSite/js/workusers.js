﻿window.onload = function () {
    console.log("Сторінка завантажилася");
    var btnAddUser = document.getElementById("btnAddUser");
    btnAddUser.onclick = ShowDialogAddStudent;

    //document.getElementById("btnCloseAddUser").onclick = HideDialogAddStudent;
    var list = document.getElementsByClassName("dlgClose");
    for (var i = 0; i < list.length; i++) {
        list[i].onclick = HideDialogAddStudent;
    }

}

function ShowDialogAddStudent() {
    var dlgAddUser = document.getElementById("dlgAddUser");
    dlgAddUser.style.display = "block";
}
function HideDialogAddStudent() {
    var dlgAddUser = document.getElementById("dlgAddUser");
    dlgAddUser.style.display = "none";
}
