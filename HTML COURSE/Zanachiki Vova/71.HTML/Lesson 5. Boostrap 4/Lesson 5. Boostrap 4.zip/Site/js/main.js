window.onload=function() {
    $("#head-menu").load("/_menu.html" );
}